#include <msp430.h>
#include "LED.h"
#define TRUE 1

// Function prototypes
void ConfigureClockModule(void);

void main(void)
{
      volatile unsigned int i;  // volatile to prevent optimization

  // Stop the watchdog timer, and configure the clock module.
  WDTCTL = WDTPW + WDTHOLD;
  ConfigureClockModule();
      
    InitializeLEDPortPins();

  // Infinite loop
    while (TRUE)
    {
        TURN_ON_GREEN_LED;
        TURN_ON_RED_LED;
      
      // Wait for approximately 1/4 second
    i = 10000;          // SW Delay
    do i--;
    while(i != 0);
      
      TURN_OFF_GREEN_LED;
      TURN_OFF_RED_LED;
      
      // Wait for approximately 1/4 second
    i = 10000;          // SW Delay
    do i--;
    while(i != 0);
    }
}

void ConfigureClockModule(void)
{
    // Configure Digitally Controlled Oscillator (DCO) using factory calibrations.
  DCOCTL  = CALDCO_1MHZ;
  BCSCTL1 = CALBC1_1MHZ;
}